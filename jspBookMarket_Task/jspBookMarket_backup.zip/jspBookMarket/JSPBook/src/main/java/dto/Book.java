package dto; // 패키지 이름 선언

import java.io.Serializable; // Serializable 인터페이스를 사용하기 위한 import

// Book 클래스 선언, Serializable 인터페이스를 구현하여 객체를 직렬화 가능하게 함
public class Book implements Serializable {

   // 직렬화를 위한 고유 ID 선언
   private static final long serialVersionUID = -427470057203867700L;
   
   // 책 정보 관련 필드 선언
   private String bookId; // 책 ID
   private String name; // 책 이름
   private int unitPrice; // 가격
   private String author; // 저자
   
   // 기본 생성자 선언
   public Book() {
      super(); // 부모 클래스의 생성자 호출
   }
   
   // 책 ID, 책 이름, 가격을 초기화하는 생성자 선언
   public Book(String bookId, String name, Integer unitPrice) {
      this.bookId = bookId; // 매개변수로 받은 값으로 bookId 초기화
      this.name = name; // 매개변수로 받은 값으로 name 초기화
      this.unitPrice = unitPrice; // 매개변수로 받은 값으로 unitPrice 초기화
   }

   // bookId 필드의 getter 메서드
   public String getBookId() {
      return bookId; // bookId 반환
   }

   // bookId 필드의 setter 메서드
   public void setBookId(String bookId) {
      this.bookId = bookId; // 매개변수로 받은 값으로 bookId 설정
   }

   // name 필드의 getter 메서드
   public String getName() {
      return name; // name 반환
   }

   // name 필드의 setter 메서드
   public void setName(String name) {
      this.name = name; // 매개변수로 받은 값으로 name 설정
   }

   // unitPrice 필드의 getter 메서드
   public int getUnitPrice() {
      return unitPrice; // unitPrice 반환
   }

   // unitPrice 필드의 setter 메서드
   public void setUnitPrice(int unitPrice) {
      this.unitPrice = unitPrice; // 매개변수로 받은 값으로 unitPrice 설정
   }

   // author 필드의 getter 메서드
   public String getAuthor() {
      return author; // author 반환
   }

   // author 필드의 setter 메서드
   public void setAuthor(String author) {
      this.author = author; // 매개변수로 받은 값으로 author 설정
   }
   
}
